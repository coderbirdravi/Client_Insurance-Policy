package com.InsuranceMyTeam.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.InsuranceMyTeam.entity.Policy;
import com.InsuranceMyTeam.repository.PolicyRepository;

@Service
public class PolicyService {

@Autowired
private PolicyRepository insurancePolicyRepository;

public List<Policy> getAllInsurancePolicies() {
return insurancePolicyRepository.findAll();
}

public Policy getInsurancePolicyById(Long id) {
Optional<Policy> policy = insurancePolicyRepository.findById(id);
if (policy.isPresent()) {
return policy.get();
} else {
return null;
}
}

public Policy createInsurancePolicy(Policy policy) {
return insurancePolicyRepository.save(policy);
}

public Policy updateInsurancePolicy(Long id, Policy policy) {
Optional<Policy> optionalPolicy = insurancePolicyRepository.findById(id);
if (optionalPolicy.isPresent()) {
Policy existingPolicy = optionalPolicy.get();
existingPolicy.setPolicyNumber(policy.getPolicyNumber());
existingPolicy.setType(policy.getType());
existingPolicy.setCoverageAmount(policy.getCoverageAmount());
existingPolicy.setPremium(policy.getPremium());
existingPolicy.setStartDate(policy.getStartDate());
existingPolicy.setEndDate(policy.getEndDate());
existingPolicy.setClient(policy.getClient());
return insurancePolicyRepository.save(existingPolicy);
} else {
return null;
}
}

public void deleteInsurancePolicy(Long id) {
insurancePolicyRepository.deleteById(id);
}
}