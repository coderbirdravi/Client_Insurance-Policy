package com.InsuranceMyTeam.exception;

public class ExceptionResponse {

}
