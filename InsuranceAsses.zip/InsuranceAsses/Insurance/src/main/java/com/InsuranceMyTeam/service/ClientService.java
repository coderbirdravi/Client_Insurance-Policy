package com.InsuranceMyTeam.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.crossstore.ChangeSetPersister.NotFoundException;
import org.springframework.stereotype.Service;

import com.InsuranceMyTeam.entity.Client;
import com.InsuranceMyTeam.repository.ClientRepository;

@Service
public class ClientService {

@Autowired
private ClientRepository clientRepository;

public List<Client> getAllClients() {
return clientRepository.findAll();
}

public Client getClientById(Long id) throws NotFoundException {
return clientRepository.findById(id).orElseThrow(() -> new NotFoundException());
}

public Client createClient(Client client) {
return clientRepository.save(client);
}

public Client updateClient(Long id, Client client) throws NotFoundException {
Client existingClient = clientRepository.findById(id)
.orElseThrow(() -> new NotFoundException());

existingClient.setName(client.getName());
existingClient.setDateOfBirth(client.getDateOfBirth());
existingClient.setAddress(client.getAddress());
existingClient.setContactInfo(client.getContactInfo());

return clientRepository.save(existingClient);
}

public void deleteClient(Long id) {
clientRepository.deleteById(id);
}
}
