package com.InsuranceMyTeam.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.InsuranceMyTeam.entity.Claim;
import com.InsuranceMyTeam.repository.ClaimRepository;

@Service
public class ClaimService {

@Autowired
private ClaimRepository claimRepository;

public List<Claim> getAllClaims() {
return claimRepository.findAll();
}

public Optional<Claim> getClaimById(Long id) {
return claimRepository.findById(id);
}

public Claim createClaim(Claim claim) {
return claimRepository.save(claim);
}

public Claim updateClaim(Long id, Claim claim) {
claim.setId(id);
return claimRepository.save(claim);
}

public void deleteClaim(Long id) {
claimRepository.deleteById(id);
}
}